//
//  WeCareALP_WatchApp.swift
//  WeCareALP_Watch Watch App
//
//  Created by student on 25/11/25.
//

import SwiftUI

@main
struct WeCareALP_Watch_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            HeartRateView()
        }
    }
}
