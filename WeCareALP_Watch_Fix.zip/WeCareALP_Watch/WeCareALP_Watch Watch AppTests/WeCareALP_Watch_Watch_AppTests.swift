//
//  WeCareALP_Watch_Watch_AppTests.swift
//  WeCareALP_Watch Watch AppTests
//
//  Created by student on 25/11/25.
//

import Testing
@testable import WeCareALP_Watch_Watch_App

struct WeCareALP_Watch_Watch_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
