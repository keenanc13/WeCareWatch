////
////  WatchModel.swift
////  WeCareALP_Watch Watch App
////
////  Created by student on 25/11/25.
////
//
//import Foundation
//
//struct HeartRateSample: Identifiable {
//    let id = UUID()
//    let bpm: Double
//    let date: Date
//}
