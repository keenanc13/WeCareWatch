import SwiftUI

struct ContentView: View {
    // Inisialisasi ViewModel utama di sini
    @StateObject private var receiverVM = ReceiverVM()
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            
            // Halaman 1: Dashboard
            WatchDashboardView(viewModel: receiverVM)
                .tag(0)
            
            // Halaman 2: Heart Rate
            HeartRateView()
                .tag(1)
            
            // Halaman 3: Games (Placeholder)
            Text("Games Coming Soon")
                .tag(2)
        }
        .tabViewStyle(.page) // Agar bisa digeser (swipe)
    }
}

#Preview {
    ContentView()
}
