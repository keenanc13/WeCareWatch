import SwiftUI

struct ContentView: View {
    // Inisialisasi ViewModel utama di sini
    @StateObject private var receiverVM = ReceiverVM()
    @State private var isLoading = true
    @State private var selectedTab = 0
    
    var body: some View {
        ZStack {
            if isLoading {
                // --- BAGIAN A: LOADING SCREEN ---
                LoadingWatchView(showMainView: .constant(true))
                    .transition(.opacity) // Efek fade out halus
                    .onAppear {
                        startAppSimulation()
                    }
            } else {
                // --- BAGIAN B: APLIKASI UTAMA (TABVIEW) ---
                TabView(selection: $selectedTab) {
                    
                    // Halaman 1: Dashboard
                    WatchDashboardView(viewModel: receiverVM)
                        .tag(0)
                    
                    // Halaman 2: Heart Rate (Pastikan View ini ada)
                    HeartRateView()
                        .tag(1)
                    
                    // Halaman 3: Games
                    VStack {
                        Image(systemName: "gamecontroller.fill")
                            .font(.largeTitle)
                            .foregroundColor(.orange)
                        Text("Games Coming Soon")
                    }
                    .tag(2)
                }
                .tabViewStyle(.page(indexDisplayMode: .always)) // Titik indikator halamanik
                .transition(.opacity) // Efek fade in halus
            }
        }
        // Animasi perpindahan antar if/else (Loading ke Utama)
        .animation(.easeInOut(duration: 0.5), value: isLoading)
    }
    
    // Fungsi untuk simulasi loading data
        func startAppSimulation() {
            // Tahan layar loading selama 3 detik
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                
                // Isi data palsu (Dummy Data) agar Dashboard terisi
                receiverVM.steps = 5420
                receiverVM.tasks = [
                    TaskItem(title: "Minum Obat Pagi", time: "08:00 AM", isCompleted: true),
                    TaskItem(title: "Jalan Sore", time: "04:30 PM", isCompleted: false),
                    TaskItem(title: "Minum Vitamin", time: "07:00 PM", isCompleted: false)
                ]
                
                // Matikan loading -> Otomatis pindah ke TabView
                isLoading = false
            }
        }
}

#Preview {
    ContentView()
}
