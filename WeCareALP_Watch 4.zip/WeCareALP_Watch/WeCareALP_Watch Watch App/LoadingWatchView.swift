import SwiftUI

struct Brand {
    static let red = Color(red: 0.95, green: 0.26, blue: 0.21)
    static let sky = Color(red: 0.4, green: 0.7, blue: 1.0)
}

struct LoadingView: View {
    @Binding var showMainView: Bool
    @State private var logoScale: CGFloat = 0.5
    @State private var logoOpacity: Double = 0
    @State private var logoY: CGFloat = -15
    @State private var ringTrim: CGFloat = 0.0
    @State private var ringRotation: Double = 0
    @State private var outerRingRotation: Double = 0
    @State private var pulseScale: CGFloat = 1.0
    @State private var textOpacity: Double = 0
    @State private var textY: CGFloat = 5
    @State private var progressOpacity: Double = 0
    @State private var fadeOut: Bool = false
    @State private var glowIntensity: Double = 0
    @State private var particleOpacity: Double = 0
    @State private var shimmerOffset: CGFloat = -300
    @State private var energyBurst: Bool = false
    @State private var orbScale1: CGFloat = 0
    @State private var orbScale2: CGFloat = 0
    @State private var orbScale3: CGFloat = 0
    @State private var particleAnimation: [Bool] = Array(repeating: false, count: 10)
    @State private var spiralRotation: Double = 0
    @State private var wavePhase: CGFloat = 0
    @State private var breathScale: CGFloat = 1.0
    @State private var liquidMorphing: CGFloat = 0
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // MARK: - BACKGROUND
                ZStack {
                    LinearGradient(
                        colors: [
                            Color(red: 0.98, green: 0.97, blue: 0.99),
                            Color(red: 0.96, green: 0.97, blue: 0.99),
                            Color(red: 0.98, green: 0.96, blue: 0.97)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    
                    // Animated mesh gradient effect
                    ZStack {
                        ForEach(0..<3) { i in
                            Circle()
                                .fill(
                                    RadialGradient(
                                        colors: [
                                            (i % 2 == 0 ? Brand.red : Brand.sky).opacity(0.1),
                                            .clear
                                        ],
                                        center: .center,
                                        startRadius: 0,
                                        endRadius: 50
                                    )
                                )
                                .frame(width: 80, height: 80)
                                .blur(radius: 20)
                                .offset(
                                    x: sin(spiralRotation * .pi / 180 + Double(i) * 1.2) * 25,
                                    y: cos(spiralRotation * .pi / 180 + Double(i) * 1.2) * 25
                                )
                                .scaleEffect(breathScale)
                        }
                    }
                }
                .ignoresSafeArea()
                .opacity(fadeOut ? 0 : 1)
                .animation(.easeInOut(duration: 0.8), value: fadeOut)
                
                // MARK: - FLOATING PARTICLES
                ZStack {
                    // Glowing orbs
                    ForEach(0..<5) { i in
                        Circle()
                            .fill(
                                RadialGradient(
                                    colors: [
                                        (i % 2 == 0 ? Brand.red : Brand.sky).opacity(0.5),
                                        .clear
                                    ],
                                    center: .center,
                                    startRadius: 0,
                                    endRadius: 5
                                )
                            )
                            .frame(width: 5, height: 5)
                            .blur(radius: 1.5)
                            .offset(
                                x: sin(wavePhase + Double(i) * 0.8) * geo.size.width * 0.3 + geo.size.width * 0.5 - geo.size.width * 0.5,
                                y: CGFloat(i) * (geo.size.height / 5) - geo.size.height * 0.3 + cos(wavePhase * 1.5 + Double(i)) * 15
                            )
                            .opacity(particleAnimation[i] ? particleOpacity : particleOpacity * 0.3)
                            .scaleEffect(particleAnimation[i] ? 1.2 : 0.8)
                            .animation(
                                .easeInOut(duration: 2)
                                .repeatForever(autoreverses: true)
                                .delay(Double(i) * 0.2),
                                value: particleAnimation[i]
                            )
                    }
                    
                    // Diamond sparkles
                    ForEach(5..<8) { i in
                        DiamondSparkle()
                            .fill(
                                LinearGradient(
                                    colors: [
                                        .white,
                                        (i % 2 == 0 ? Brand.red : Brand.sky).opacity(0.7)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 4, height: 4)
                            .rotationEffect(.degrees(particleAnimation[i] ? 360 : 0))
                            .offset(
                                x: CGFloat.random(in: -50...50),
                                y: CGFloat(i - 5) * 30 - 30
                            )
                            .opacity(particleAnimation[i] ? particleOpacity * 0.8 : particleOpacity * 0.3)
                            .scaleEffect(particleAnimation[i] ? 1.2 : 0.7)
                            .shadow(color: (i % 2 == 0 ? Brand.red : Brand.sky).opacity(0.5), radius: 3)
                            .animation(
                                .easeInOut(duration: 2.5)
                                .repeatForever(autoreverses: true)
                                .delay(Double(i) * 0.15),
                                value: particleAnimation[i]
                            )
                    }
                }
                
                // MARK: - MAIN CONTENT
                VStack(spacing: 12) {
                    ZStack {
                        // ENERGY BURST
                        ForEach(0..<3) { i in
                            Circle()
                                .stroke(
                                    AngularGradient(
                                        colors: [
                                            Brand.red.opacity(0.25 - Double(i) * 0.06),
                                            Brand.sky.opacity(0.23 - Double(i) * 0.06)
                                        ],
                                        center: .center
                                    ),
                                    lineWidth: 1
                                )
                                .frame(width: 65 + CGFloat(i) * 12, height: 65 + CGFloat(i) * 12)
                                .scaleEffect(energyBurst ? 1.4 + CGFloat(i) * 0.12 : 0.8)
                                .opacity(energyBurst ? 0 : 0.5)
                                .blur(radius: CGFloat(i + 1))
                                .rotationEffect(.degrees(Double(i) * 12 + spiralRotation * 0.5))
                        }
                        
                        // LIQUID RINGS
                        ForEach(0..<2) { layer in
                            LiquidRing(morphAmount: liquidMorphing, offset: Double(layer) * 0.3)
                                .stroke(
                                    AngularGradient(
                                        gradient: Gradient(colors: [
                                            Brand.red.opacity(0.3),
                                            Brand.sky.opacity(0.35),
                                            Brand.red.opacity(0.3)
                                        ]),
                                        center: .center
                                    ),
                                    lineWidth: 1.5
                                )
                                .frame(width: 60 - CGFloat(layer) * 8, height: 60 - CGFloat(layer) * 8)
                                .rotationEffect(.degrees(-outerRingRotation + Double(layer) * 45))
                                .shadow(color: Brand.sky.opacity(0.25), radius: 6, x: 0, y: 0)
                        }
                        
                        // MAIN PROGRESS RING
                        ZStack {
                            Circle()
                                .trim(from: 0, to: ringTrim)
                                .stroke(
                                    AngularGradient(
                                        gradient: Gradient(colors: [
                                            Brand.red,
                                            Brand.sky,
                                            Brand.red
                                        ]),
                                        center: .center
                                    ),
                                    style: StrokeStyle(lineWidth: 3.5, lineCap: .round)
                                )
                                .frame(width: 90, height: 90)
                                .rotationEffect(.degrees(ringRotation))
                                .shadow(color: Brand.red.opacity(0.4), radius: 5, x: 0, y: 0)
                                .shadow(color: Brand.sky.opacity(0.3), radius: 6, x: 0, y: 0)
                        }
                        
                        // GLOW LAYERS
                        ForEach(0..<2) { i in
                            Circle()
                                .fill(
                                    RadialGradient(
                                        colors: [
                                            (i % 2 == 0 ? Brand.sky : Brand.red).opacity(0.1),
                                            .clear
                                        ],
                                        center: .center,
                                        startRadius: CGFloat(i) * 8,
                                        endRadius: 40 + CGFloat(i) * 8
                                    )
                                )
                                .frame(width: 75, height: 75)
                                .scaleEffect(pulseScale + CGFloat(i) * 0.02)
                                .blur(radius: CGFloat(i + 2) * 1.5)
                                .rotationEffect(.degrees(spiralRotation * 0.3 + Double(i) * 15))
                        }
                        
                        // GLASS CIRCLE
                        ZStack {
                            Circle()
                                .fill(
                                    RadialGradient(
                                        colors: [
                                            .white,
                                            Color(red: 0.96, green: 0.97, blue: 0.98)
                                        ],
                                        center: UnitPoint(x: 0.4, y: 0.4),
                                        startRadius: 0,
                                        endRadius: 40
                                    )
                                )
                                .frame(width: 78, height: 78)
                                .shadow(color: .black.opacity(0.08), radius: 8, y: 3)
                        }
                        
                        // LOGO
                        ZStack {
                            Image("WeCareLogo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 60, height: 60)
                        }
                        .scaleEffect(logoScale)
                        .opacity(logoOpacity)
                        .offset(y: logoY)
                        .shadow(color: Brand.sky.opacity(glowIntensity * 0.3), radius: 10, x: 0, y: 0)
                        
                        // ORBITING ICONS
                        ForEach(0..<3) { i in
                            let angle = Double(i) * 120.0 + spiralRotation * 0.5
                            let radius = 48.0 + sin(wavePhase + Double(i)) * 2
                            let x = radius * cos(angle * .pi / 180 - .pi / 2)
                            let y = radius * sin(angle * .pi / 180 - .pi / 2)
                            let iconName = i == 0 ? "heart.fill" : (i == 1 ? "hands.sparkles.fill" : "figure.2.arms.open")
                            let scale = i == 0 ? orbScale1 : (i == 1 ? orbScale2 : orbScale3)
                            
                            ZStack {
                                Circle()
                                    .fill(
                                        RadialGradient(
                                            colors: [
                                                .white.opacity(0.95),
                                                .white.opacity(0.85)
                                            ],
                                            center: UnitPoint(x: 0.3, y: 0.3),
                                            startRadius: 0,
                                            endRadius: 10
                                        )
                                    )
                                    .frame(width: 20, height: 20)
                                    .shadow(color: .black.opacity(0.12), radius: 3, y: 1)
                                
                                Image(systemName: iconName)
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundStyle(
                                        LinearGradient(
                                            colors: [
                                                i == 0 ? Brand.red : Brand.sky,
                                                (i == 0 ? Brand.red : Brand.sky).opacity(0.7)
                                            ],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                            }
                            .scaleEffect(scale * breathScale)
                            .offset(x: x, y: y)
                            .rotationEffect(.degrees(-ringRotation))
                            .opacity(logoOpacity)
                        }
                    }
                    
                    // TEXT SECTION
                    VStack(spacing: 5) {
                        Text("WeCare")
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [Brand.red, Brand.sky],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                        
                        Text("Connecting families")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(Color(red: 0.3, green: 0.35, blue: 0.45))
                    }
                    .offset(y: textY)
                    .opacity(textOpacity)
                    
                    // PROGRESS INDICATORS
                    HStack(spacing: 6) {
                        ForEach(0..<3) { i in
                            Circle()
                                .fill(
                                    RadialGradient(
                                        colors: [
                                            .white,
                                            (i % 2 == 0 ? Brand.red : Brand.sky)
                                        ],
                                        center: .center,
                                        startRadius: 0,
                                        endRadius: 4
                                    )
                                )
                                .frame(width: 5, height: 5)
                                .scaleEffect(progressOpacity > Double(i) * 0.33 ? 1.3 : 0.6)
                                .opacity(progressOpacity > Double(i) * 0.33 ? 1.0 : 0.3)
                                .shadow(
                                    color: (i % 2 == 0 ? Brand.red : Brand.sky).opacity(0.7),
                                    radius: progressOpacity > Double(i) * 0.33 ? 5 : 2
                                )
                                .animation(
                                    .easeInOut(duration: 0.7)
                                    .repeatForever()
                                    .delay(Double(i) * 0.22),
                                    value: progressOpacity
                                )
                        }
                    }
                    .padding(.top, 4)
                    .opacity(progressOpacity)
                }
                .opacity(fadeOut ? 0 : 1)
                .animation(.easeInOut(duration: 0.7), value: fadeOut)
            }
        }
        .onAppear {
            startAnimations()
            
            // Transition after loading
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.8) {
                withAnimation(.easeInOut(duration: 0.8)) {
                    fadeOut = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    showMainView = false
                }
            }
        }
    }
    
    // MARK: - ANIMATIONS
    private func startAnimations() {
        // Activate particles
        for i in 0..<particleAnimation.count {
            particleAnimation[i] = true
        }
        
        withAnimation(.linear(duration: 15).repeatForever(autoreverses: false)) {
            spiralRotation = 360
        }
        
        withAnimation(.linear(duration: 6).repeatForever(autoreverses: false)) {
            wavePhase = .pi * 4
        }
        
        withAnimation(.easeInOut(duration: 2.5).repeatForever(autoreverses: true)) {
            breathScale = 1.06
        }
        
        withAnimation(.easeInOut(duration: 3).repeatForever(autoreverses: true)) {
            liquidMorphing = 1.0
        }
        
        withAnimation(.easeOut(duration: 1.5).delay(0.1)) {
            energyBurst = true
        }
        
        withAnimation(.easeIn(duration: 1.0).delay(0.2)) {
            particleOpacity = 1.0
        }
        
        withAnimation(.interpolatingSpring(stiffness: 60, damping: 7).delay(0.4)) {
            logoY = 0
            logoScale = 1.06
            logoOpacity = 1.0
        }
        
        withAnimation(.easeOut(duration: 0.6).delay(1.0)) {
            logoScale = 1.0
        }
        
        withAnimation(.easeOut(duration: 1.8).delay(0.6)) {
            ringTrim = 1.0
        }
        
        withAnimation(.linear(duration: 20).repeatForever(autoreverses: false).delay(0.8)) {
            ringRotation = 360
        }
        
        withAnimation(.linear(duration: 25).repeatForever(autoreverses: false).delay(0.8)) {
            outerRingRotation = 360
        }
        
        withAnimation(.easeInOut(duration: 2.5).repeatForever(autoreverses: true).delay(0.9)) {
            pulseScale = 1.12
        }
        
        withAnimation(.easeInOut(duration: 2.2).repeatForever(autoreverses: true).delay(1.0)) {
            glowIntensity = 1.0
        }
        
        withAnimation(.interpolatingSpring(stiffness: 80, damping: 6).delay(0.9)) {
            orbScale1 = 1.0
        }
        
        withAnimation(.interpolatingSpring(stiffness: 80, damping: 6).delay(1.1)) {
            orbScale2 = 1.0
        }
        
        withAnimation(.interpolatingSpring(stiffness: 80, damping: 6).delay(1.3)) {
            orbScale3 = 1.0
        }
        
        withAnimation(.spring(response: 0.8, dampingFraction: 0.7).delay(1.4)) {
            textY = 0
            textOpacity = 1.0
        }
        
        withAnimation(.easeIn(duration: 0.7).delay(1.7)) {
            progressOpacity = 1.0
        }
    }
}

// MARK: - Custom Shapes
struct DiamondSparkle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let width = rect.width
        let height = rect.height
        
        path.move(to: CGPoint(x: center.x, y: center.y - height/2))
        path.addLine(to: CGPoint(x: center.x + width/2, y: center.y))
        path.addLine(to: CGPoint(x: center.x, y: center.y + height/2))
        path.addLine(to: CGPoint(x: center.x - width/2, y: center.y))
        path.closeSubpath()
        
        return path
    }
}

struct LiquidRing: Shape {
    var morphAmount: CGFloat
    var offset: Double
    
    var animatableData: CGFloat {
        get { morphAmount }
        set { morphAmount = newValue }
    }
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        let points = 30
        
        path.move(to: CGPoint(
            x: center.x + radius,
            y: center.y
        ))
        
        for i in 0..<points {
            let angle = (Double(i) / Double(points)) * 2 * .pi
            let wave = sin(angle * 4 + morphAmount * .pi * 2 + offset) * 1.5
            let r = radius + CGFloat(wave)
            let x = center.x + r * cos(angle)
            let y = center.y + r * sin(angle)
            path.addLine(to: CGPoint(x: x, y: y))
        }
        
        path.closeSubpath()
        return path
    }
}

#Preview {
    LoadingView(showMainView: .constant(true))
}
