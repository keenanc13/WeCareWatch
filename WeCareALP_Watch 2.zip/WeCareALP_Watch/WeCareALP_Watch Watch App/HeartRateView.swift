import SwiftUI
import Combine

// MARK: - 1. Model Data
struct HeartRateSample: Identifiable {
    let id = UUID()
    let bpm: Double
    let date: Date
}

// MARK: - 2. ViewModel (Simulasi / Tanpa HealthKit)
class HeartRateViewModel: ObservableObject {
    @Published var currentBPM: Double = 0
    @Published var recentSamples: [HeartRateSample] = []
    @Published var isRunning = false

    private var timer: Timer?

    // Memulai simulasi
    func start() {
        guard !isRunning else { return }
        isRunning = true
        
        // Timer update setiap 1 detik
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            // Random BPM antara 65 sampai 115 biar terlihat hidup
            let randomBPM = Double.random(in: 65...115)
            self.updateData(bpm: randomBPM)
        }
    }

    // Stop simulasi
    func stop() {
        isRunning = false
        timer?.invalidate()
        timer = nil
    }
    
    private func updateData(bpm: Double) {
        // Pastikan update UI di Main Thread
        DispatchQueue.main.async {
            self.currentBPM = bpm
            
            let sample = HeartRateSample(bpm: bpm, date: Date())
            self.recentSamples.append(sample)
            
            // Batasi array agar tidak memakan memori (max 50)
            if self.recentSamples.count > 50 {
                self.recentSamples.removeFirst()
            }
        }
    }
}

// MARK: - 3. Color Extension
extension Color {
    static let brandYellow = Color(hex: "fdcb46")
    static let brandRed = Color(hex: "fa6255")
    static let brandGreen = Color(hex: "a6d17d")
    static let brandSky = Color(hex: "91bef8")
    static let brandLilac = Color(hex: "e1c7ec")

    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(.sRGB, red: Double(r)/255, green: Double(g)/255, blue: Double(b)/255, opacity: Double(a)/255)
    }
}

// MARK: - 4. Main View
struct HeartRateView: View {
    // ViewModel diinisialisasi di sini
    @StateObject private var vm = HeartRateViewModel()
    
    // State untuk animasi
    @State private var isPulsing = false

    // Computed Properties
    private var bpmString: String {
        vm.currentBPM > 0 ? String(format: "%.0f", vm.currentBPM) : "--"
    }
    
    private var chartSamples: [HeartRateSample] {
        Array(vm.recentSamples.suffix(25))
    }

    var body: some View {
        ZStack {
            // Background
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 4) {
                // Header
                Text("HR SIMULATOR")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(2)
                    .foregroundColor(Color.brandLilac)
                    .padding(.top, 2)

                Spacer()

                // Main Indicator
                mainIndicatorView

                // Status Text
                Text("BEATS PER MINUTE")
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundColor(.gray)

                Spacer()
                
                // Chart
                chartView

                Spacer()

                // Controls
                controlButton
            }
            .padding(.horizontal)
            .padding(.bottom, 6)
        }
        // Trigger animasi
        .onChange(of: vm.currentBPM) { newValue in
            if vm.isRunning && newValue > 0 {
                withAnimation(.easeOut(duration: 0.1)) { isPulsing = true }
                withAnimation(.easeIn(duration: 0.4).delay(0.1)) { isPulsing = false }
            }
        }
    }

    // Subviews
    private var mainIndicatorView: some View {
        HStack(alignment: .center, spacing: 8) {
            Image(systemName: "heart.fill")
                .font(.system(size: 24))
                .foregroundColor(Color.brandRed)
                .scaleEffect(isPulsing ? 1.3 : 1.0)
                .shadow(color: Color.brandRed.opacity(0.6), radius: isPulsing ? 10 : 0)
            
            Text(bpmString)
                .font(.system(size: 64, weight: .black, design: .rounded))
                .foregroundColor(.white)
                .shadow(color: vm.currentBPM > 100 ? Color.brandYellow.opacity(0.4) : .clear, radius: 10)
        }
    }

    @ViewBuilder
    private var chartView: some View {
        if !vm.recentSamples.isEmpty {
            HStack(alignment: .bottom, spacing: 3) {
                ForEach(chartSamples) { sample in
                    barView(for: sample)
                }
            }
            .frame(height: 35)
            .transition(.opacity)
        } else {
            VStack(spacing: 4) {
                Image(systemName: "waveform.path.ecg")
                    .font(.title3)
                    .foregroundColor(Color.brandSky.opacity(0.4))
                Text("Press Start to Simulate")
                    .font(.caption2)
                    .foregroundColor(Color.brandLilac.opacity(0.6))
            }
            .frame(height: 35)
        }
    }
    
    private func barView(for sample: HeartRateSample) -> some View {
        let ratio = sample.bpm / 160.0
        let height = max(0.1, min(1.0, ratio))
        let isLatest = sample.id == vm.recentSamples.last?.id
        
        return RoundedRectangle(cornerRadius: 2)
            .fill(
                LinearGradient(
                    gradient: Gradient(colors: [Color.brandSky, Color.brandLilac]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .frame(width: 4, height: 35 * height)
            .opacity(isLatest ? 1.0 : 0.4)
            .animation(.spring(), value: height)
    }
    
    private var controlButton: some View {
        Button(action: {
            if vm.isRunning {
                vm.stop()
                withAnimation { isPulsing = false }
            } else {
                vm.start()
            }
        }) {
            ZStack {
                Capsule()
                    .fill(vm.isRunning ? Color.brandRed : Color.brandGreen)
                
                HStack {
                    Image(systemName: vm.isRunning ? "stop.fill" : "play.fill")
                    Text(vm.isRunning ? "STOP" : "START")
                        .fontWeight(.bold)
                }
                .foregroundColor(vm.isRunning ? .white : .black)
            }
        }
        .frame(height: 44)
        .buttonStyle(.plain)
        .shadow(color: (vm.isRunning ? Color.brandRed : Color.brandGreen).opacity(0.5), radius: 6, x: 0, y: 3)
    }
}

#Preview {
    HeartRateView()
}
