import SwiftUI

struct ContentView: View {
    // Inisialisasi ViewModel utama di sini
    @StateObject private var receiverVM = ReceiverVM()
    @State private var isLoading = true
    
    var body: some View {
        ZStack {
            if isLoading {
                // --- BAGIAN A: LOADING SCREEN ---
                LoadingView(showMainView: .constant(true))
                    .transition(.opacity) // Efek fade out halus
                    .onAppear {
                        startAppSimulation()
                    }
            } else {
                // --- BAGIAN B: APLIKASI UTAMA ---
                // Saat view ini muncul, dia akan otomatis mengecek jam tugas
                WatchDashboardView(viewModel: receiverVM)
                    .transition(.opacity) // Efek fade in halus
            }
        }
        // Animasi perpindahan antar if/else
        .animation(.easeInOut(duration: 0.5), value: isLoading)
    }
    
    // Fungsi untuk simulasi loading data
    func startAppSimulation() {
        // Tahan layar loading selama 3 detik
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            
            // 1. Setup Formatter (24 Jam)
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm" // Format 24 Jam (Contoh: 14:30)
            
            // 2. Buat waktu "1 Jam yang Lalu" secara otomatis
            // Ini agar Alert PASTI MUNCUL saat Anda mengetesnya kapanpun
            let satuJamLalu = Calendar.current.date(byAdding: .hour, value: -1, to: Date()) ?? Date()
            let jamTelat = formatter.string(from: satuJamLalu) // Jadi String
            
            // 3. Isi Data Dummy
            receiverVM.steps = 5420
            receiverVM.tasks = [
                // TASK 1: Sudah selesai (Aman)
                TaskItem(title: "Minum Obat Pagi", time: "08:00", isCompleted: true),
                
                // TASK 2: SENGAJA DIBUAT TELAT (Overdue)
                // Jamnya diset otomatis 1 jam yang lalu & status belum selesai
                TaskItem(title: "Cek Tensi (Garam & Madu)", time: jamTelat, isCompleted: false),
                
                // TASK 3: Nanti malam (Aman)
                TaskItem(title: "Minum Vitamin", time: "20:00", isCompleted: false)
            ]
            
            // Matikan loading -> Pindah ke Dashboard -> Trigger Alert
            isLoading = false
        }
    }
}

#Preview {
    ContentView()
}
