import Foundation
import Combine // <--- Tambahkan ini agar @Published dan ObservableObject dikenali
// atau 'import SwiftUI' juga boleh

struct TaskItem: Identifiable {
    let id = UUID()
    let title: String
    let time: String
    var isCompleted: Bool
}

class ReceiverVM: ObservableObject {
    @Published var steps: Int = 4500
    @Published var tasks: [TaskItem] = [
        TaskItem(title: "Minum Obat", time: "08:00", isCompleted: true),
        TaskItem(title: "Cek Tensi", time: "12:00", isCompleted: false),
        TaskItem(title: "Jalan Sore", time: "16:30", isCompleted: false)
    ]
    
    func toggleTaskCompletion(for id: UUID) {
        if let index = tasks.firstIndex(where: { $0.id == id }) {
            tasks[index].isCompleted.toggle()
        }
    }
}
