//// ViewModel Simulasi
//class HeartRateViewModel: ObservableObject {
//    @Published var currentBPM: Double = 0
//    @Published var recentSamples: [HeartRateSample] = []
//    @Published var isRunning = false
//
//    private var timer: Timer?
//
//    // Memulai simulasi detak jantung
//    func start() {
//        guard !isRunning else { return }
//        isRunning = true
//        
//        // Timer update setiap 1 detik
//        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
//            guard let self = self else { return }
//            
//            // Random BPM antara 65 sampai 115 biar terlihat hidup
//            let randomBPM = Double.random(in: 65...115)
//            self.updateData(bpm: randomBPM)
//        }
//    }
//
//    func stop() {
//        isRunning = false
//        timer?.invalidate()
//        timer = nil
//        // Reset angka ke 0 saat stop (opsional)
//        // currentBPM = 0
//    }
//    
//    private func updateData(bpm: Double) {
//        DispatchQueue.main.async {
//            self.currentBPM = bpm
//            
//            let sample = HeartRateSample(bpm: bpm, date: Date())
//            self.recentSamples.append(sample)
//            
//            // Keep max 50 data points
//            if self.recentSamples.count > 50 {
//                self.recentSamples.removeFirst()
//            }
//        }
//    }
//}
