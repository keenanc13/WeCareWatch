//
//  LoadingWatchView.swift
//  WeCareALP_Watch Watch App
//
//  Created by student on 27/11/25.
//

import SwiftUI

struct LoadingWatchView: View {
    @Binding var showMainView: Bool
    
    // Animation states
    @State private var isPulsing = false
    @State private var ringTrim: CGFloat = 0.0
    @State private var ringRotation: Double = 0
    @State private var logoScale: CGFloat = 0.85
    @State private var fadeOut = false
    @State private var textOpacity: Double = 0
    
    var body: some View {
        ZStack {
            // MARK: - Gradient Background (adapted for Watch)
            LinearGradient(
                colors: [
                    Color(red: 10/255, green: 18/255, blue: 40/255),   // deep navy
                    Color(red: 24/255, green: 41/255, blue: 89/255),  // royal blue
                    Color(red: 250/255, green: 198/255, blue: 70/255).opacity(0.3) // subtle gold
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .overlay(
                // Subtle blur circles for depth
                ZStack {
                    Circle()
                        .fill(Color.white.opacity(0.08))
                        .frame(width: 100, height: 100)
                        .blur(radius: 20)
                        .offset(x: -40, y: -50)
                    
                    Circle()
                        .fill(Color.yellow.opacity(0.12))
                        .frame(width: 80, height: 80)
                        .blur(radius: 25)
                        .offset(x: 40, y: 50)
                }
            )
            .opacity(fadeOut ? 0 : 1)
            
            // MARK: - Main Content
            VStack(spacing: 16) {
                ZStack {
                    // Animated golden ring (smaller for Watch)
                    Circle()
                        .trim(from: 0, to: ringTrim)
                        .stroke(
                            AngularGradient(
                                gradient: Gradient(colors: [
                                    Color.yellow.opacity(0.3),
                                    Color.white.opacity(0.9),
                                    Color.yellow.opacity(0.7),
                                    Color.white.opacity(0.9),
                                    Color.yellow.opacity(0.3)
                                ]),
                                center: .center
                            ),
                            style: StrokeStyle(lineWidth: 3, lineCap: .round)
                        )
                        .frame(width: 90, height: 90)
                        .rotationEffect(.degrees(ringRotation))
                        .blur(radius: 0.2)
                        .shadow(color: .yellow.opacity(0.4), radius: 8, x: 0, y: 0)
                    
                    // Heart icon with pulse animation
                    ZStack {
                        // Outer glow circle
                        Circle()
                            .fill(Color.blue.opacity(0.15))
                            .frame(width: 70, height: 70)
                            .scaleEffect(isPulsing ? 1.1 : 0.9)
                        
                        // --- PERUBAHAN DI SINI ---
                        Image("WeCareLogo") // Menggunakan asset custom
                            .resizable()
                            .scaledToFit()
                            .frame(width: 45, height: 45) // Sedikit disesuaikan ukurannya
                            // .foregroundColor(.white) // Hapus baris ini jika logo Anda sudah berwarna (bukan template image)
                            .scaleEffect(logoScale)
                            .shadow(
                                color: Color.white.opacity(isPulsing ? 0.7 : 0.3),
                                radius: isPulsing ? 15 : 5,
                                x: 0, y: 0
                            )
                    }
                }
                
                // MARK: - Text Content
                VStack(spacing: 4) {
                    Text("WeCare")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .opacity(textOpacity)
                    
                    Text("Menjaga dengan Cinta")
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.75))
                        .opacity(textOpacity)
                }
                
                // MARK: - Progress Indicator
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: Color.yellow.opacity(0.9)))
                    .scaleEffect(0.9)
                    .padding(.top, 4)
                    .opacity(textOpacity)
            }
            .opacity(fadeOut ? 0 : 1)
        }
        .onAppear {
            startAnimations()
            
            // Simulate loading then transition
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                withAnimation(.easeInOut(duration: 0.6)) {
                    fadeOut = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    showMainView = false // Logic ini akan mengganti ke Main View jika Binding diatur dengan benar
                }
            }
        }
    }
    
    // MARK: - Animation Functions
    private func startAnimations() {
        // Ring trim animation
        withAnimation(.easeOut(duration: 1.0)) {
            ringTrim = 1.0
        }
        
        // Ring rotation (continuous)
        withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) {
            ringRotation = 360
        }
        
        // Pulse animation
        withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) {
            isPulsing = true
            logoScale = 1.05
        }
        
        // Text fade in
        withAnimation(.easeIn(duration: 0.8).delay(0.3)) {
            textOpacity = 1.0
        }
    }
}

// MARK: - Preview
#Preview {
    LoadingWatchView(showMainView: .constant(true))
}
