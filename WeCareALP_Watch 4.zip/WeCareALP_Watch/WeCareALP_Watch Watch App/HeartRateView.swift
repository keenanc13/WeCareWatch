import SwiftUI
import Combine

// MARK: - 1. Model Data
struct HeartRateSample: Identifiable {
    let id = UUID()
    let bpm: Double
    let date: Date
}

// MARK: - 2. ViewModel (Simulasi / Tanpa HealthKit)
class HeartRateViewModel: ObservableObject {
    @Published var currentBPM: Double = 0
    @Published var recentSamples: [HeartRateSample] = []
    @Published var isRunning = false

    private var timer: Timer?

    // Memulai simulasi
    func start() {
        guard !isRunning else { return }
        isRunning = true
        
        // Timer update setiap 1 detik
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            // Random BPM antara 65 sampai 115 biar terlihat hidup
            let randomBPM = Double.random(in: 65...115)
            self.updateData(bpm: randomBPM)
        }
    }

    // Stop simulasi
    func stop() {
        isRunning = false
        timer?.invalidate()
        timer = nil
    }
    
    private func updateData(bpm: Double) {
        // Pastikan update UI di Main Thread
        DispatchQueue.main.async {
            self.currentBPM = bpm
            
            let sample = HeartRateSample(bpm: bpm, date: Date())
            self.recentSamples.append(sample)
            
            // Batasi array agar tidak memakan memori (max 50)
            if self.recentSamples.count > 50 {
                self.recentSamples.removeFirst()
            }
        }
    }
}

// MARK: - 3. Color Extension
extension Color {
    static let brandYellow = Color(hex: "fdcb46")
    static let brandRed = Color(hex: "fa6255")
    static let brandGreen = Color(hex: "a6d17d")
    static let brandSky = Color(hex: "91bef8")
    static let brandLilac = Color(hex: "e1c7ec")

    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(.sRGB, red: Double(r)/255, green: Double(g)/255, blue: Double(b)/255, opacity: Double(a)/255)
    }
}

// MARK: - 4. Main View
struct HeartRateView: View {
    @StateObject private var vm = HeartRateViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var isPulsing = false

    // Mengambil referensi warna (sesuaikan jika perlu)
    let primaryColor = Color.brandNavy
    let accentColor = Color.brandLightBlue

    private var bpmString: String {
        vm.currentBPM > 0 ? String(format: "%.0f", vm.currentBPM) : "--"
    }
    
    var body: some View {
        ZStack {
            // 1. Background PUTIH
            Color.white.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {

                // Main Indicator (Jantung & Angka)
                VStack(spacing: 0) {
                    Image(systemName: "heart.fill")
                        .font(.system(size: 50))
                        .foregroundColor(.red)
                        .scaleEffect(isPulsing ? 1.2 : 1.0)
                        .shadow(color: .red.opacity(0.3), radius: isPulsing ? 10 : 0)
                        .padding(.top, 10)
                    
                    Text(bpmString)
                        .font(.system(size: 72, weight: .black, design: .rounded))
                        .foregroundColor(primaryColor) // Warna Gelap
                        .contentTransition(.numericText()) // Animasi transisi angka
                        .padding(.top, 10)
                    
                    Text("BEATS PER MINUTE")
                        .font(.system(size: 10, weight: .bold))
                        .tracking(1)
                        .foregroundColor(.gray)
                }

                Spacer()
                
                // Chart View
                HStack(alignment: .bottom, spacing: 4) {
                    if vm.recentSamples.isEmpty {
                        Text("Measuring...")
                            .font(.caption)
                            .foregroundColor(.gray)
                            .frame(height: 50)
                    } else {
                        ForEach(Array(vm.recentSamples.suffix(20))) { sample in
                            barView(for: sample)
                        }
                    }
                }
                .frame(height: 50)
                .padding(.top, 5)
            }
            .padding(.horizontal)
        }
        // 2. Auto Start saat View Muncul
        .onAppear {
            vm.start()
        }
        // 3. Auto Stop saat View Hilang (Hemat Baterai)
        .onDisappear {
            vm.stop()
        }
        // 4. Animasi Detak Jantung
        .onChange(of: vm.currentBPM) { newValue in
            if newValue > 0 {
                withAnimation(.easeOut(duration: 0.15)) { isPulsing = true }
                withAnimation(.easeIn(duration: 0.45).delay(0.15)) { isPulsing = false }
            }
        }
    }
    
    // Helper untuk batang grafik
    private func barView(for sample: HeartRateSample) -> some View {
        let ratio = (sample.bpm - 50) / 80.0 // Normalisasi simpel
        let height = max(0.1, min(1.0, ratio)) * 40
        let isLatest = sample.id == vm.recentSamples.last?.id
        
        return RoundedRectangle(cornerRadius: 2)
            .fill(
                LinearGradient(
                    colors: [accentColor, accentColor.opacity(0.4)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .frame(width: 8, height: CGFloat(height))
            .opacity(isLatest ? 1.0 : 0.4)
            .animation(.spring(), value: height)
    }
}

#Preview {
    HeartRateView()
}
