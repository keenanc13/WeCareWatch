import SwiftUI
import Combine

// MARK: - Extended Color Palette
extension Color {
    static let brandNavy = Color(red: 10/255, green: 18/255, blue: 40/255)
    static let brandLightBlue = Color(red: 100/255, green: 181/255, blue: 246/255)
    static let watchBackground = Color(red: 0.95, green: 0.95, blue: 0.97)
}

// MARK: - MAIN VIEW
struct WatchDashboardView: View {
    @ObservedObject var viewModel: ReceiverVM
    @State private var selectedTab: DashboardTab = .overview
    
    private let stepGoal = 6000
    
    // Menghitung persentase langkah (max 100)
    private var stepProgressPercentage: Int {
        min(Int(Double(viewModel.steps) / Double(stepGoal) * 100), 100)
    }
    
    // Menghitung persentase tugas
    private var taskCompletionPercentage: Int {
        guard !viewModel.tasks.isEmpty else { return 0 }
        let completed = viewModel.tasks.filter { $0.isCompleted }.count
        return Int(Double(completed) / Double(viewModel.tasks.count) * 100)
    }
    
    // Hitung sisa tugas
    private var remainingTasks: Int {
        viewModel.tasks.filter { !$0.isCompleted }.count
    }
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // TAB 1: Overview
            OverviewTabView(
                viewModel: viewModel,
                taskCompletionPercentage: taskCompletionPercentage,
                stepProgressPercentage: stepProgressPercentage,
                stepGoal: stepGoal,
                remainingTasks: remainingTasks
            )
            .tag(DashboardTab.overview)
            
            // TAB 2: Tasks Detail
            TasksTabView(viewModel: viewModel)
                .tag(DashboardTab.tasks)
            
            // TAB 3: Health Stats
            HealthTabView(
                viewModel: viewModel,
                stepProgressPercentage: stepProgressPercentage,
                stepGoal: stepGoal
            )
            .tag(DashboardTab.health)
        }
        .tabViewStyle(.page)
    }
}

// MARK: - Dashboard Tabs Enum
enum DashboardTab {
    case overview, tasks, health
}

// MARK: - TAB 1: OVERVIEW
struct OverviewTabView: View {
    @ObservedObject var viewModel: ReceiverVM
    let taskCompletionPercentage: Int
    let stepProgressPercentage: Int
    let stepGoal: Int
    let remainingTasks: Int
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                // HEADER with Gradient
                VStack(alignment: .leading, spacing: 4) {
                    Text(greetingMessage())
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white.opacity(0.8))
                    
                    Text("Grandpa")
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 14)
                .padding(.vertical, 16)
                .background(
                    LinearGradient(
                        colors: [Color.brandSky, Color.brandLightBlue],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .cornerRadius(18)
                .shadow(color: Color.brandSky.opacity(0.3), radius: 6, x: 0, y: 3)
                .padding(.horizontal, 8)
                .padding(.top, 4)
                
                // HERO CARD: Task Progress with Glow Effect
                VStack(spacing: 10) {
                    ZStack {
                        // Outer glow circle
                        Circle()
                            .fill(
                                RadialGradient(
                                    colors: [
                                        Color.brandGreen.opacity(0.2),
                                        Color.clear
                                    ],
                                    center: .center,
                                    startRadius: 50,
                                    endRadius: 75
                                )
                            )
                            .frame(width: 120, height: 120)
                        
                        // Background Circle
                        Circle()
                            .stroke(Color.brandGreen.opacity(0.15), lineWidth: 10)
                            .frame(width: 100, height: 100)
                        
                        // Animated Progress Circle
                        Circle()
                            .trim(from: 0, to: CGFloat(taskCompletionPercentage) / 100.0)
                            .stroke(
                                LinearGradient(
                                    colors: [Color.brandGreen, Color.brandGreen.opacity(0.7)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                style: StrokeStyle(lineWidth: 10, lineCap: .round)
                            )
                            .frame(width: 100, height: 100)
                            .rotationEffect(.degrees(-90))
                            .shadow(color: Color.brandGreen.opacity(0.4), radius: 6, x: 0, y: 0)
                        
                        // Center Content
                        VStack(spacing: 1) {
                            Text("\(taskCompletionPercentage)%")
                                .font(.system(size: 34, weight: .bold, design: .rounded))
                                .foregroundColor(Color.brandGreen)
                            
                            Text("Tasks Done")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.vertical, 6)
                    
                    // Quick Stats Row
                    HStack(spacing: 16) {
                        QuickStatBadge(
                            icon: "checkmark.circle.fill",
                            value: "\(viewModel.tasks.filter { $0.isCompleted }.count)",
                            label: "Done",
                            color: .brandGreen
                        )
                        
                        QuickStatBadge(
                            icon: "clock.fill",
                            value: "\(remainingTasks)",
                            label: "Pending",
                            color: .brandYellow
                        )
                    }
                }
                .padding(16)
                .background(Color.white)
                .cornerRadius(18)
                .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 3)
                .padding(.horizontal, 8)
                
                // QUICK ACCESS CARDS
                VStack(spacing: 10) {
                    // Steps Mini Card
                    QuickAccessCard(
                        icon: "figure.walk",
                        title: "Steps Today",
                        value: "\(viewModel.steps)",
                        subtitle: "\(stepProgressPercentage)% of goal",
                        color: .brandLightBlue,
                        progress: CGFloat(stepProgressPercentage) / 100.0
                    )
                    
                    // Next Task Card
                    if let nextTask = viewModel.tasks.first(where: { !$0.isCompleted }) {
                        NextTaskCard(task: nextTask)
                    }
                }
                .padding(.horizontal, 8)
                
                // Spacer for bottom padding
                Color.clear.frame(height: 20)
            }
        }
        .background(Color.watchBackground)
    }
    
    private func greetingMessage() -> String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 0..<12: return "Good Morning"
        case 12..<17: return "Good Afternoon"
        default: return "Good Evening"
        }
    }
}

// MARK: - TAB 2: TASKS DETAIL
struct TasksTabView: View {
    @ObservedObject var viewModel: ReceiverVM
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 14) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("DAILY")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(Color.brandYellow)
                            .tracking(1.2)
                        Text("Tasks")
                            .font(.system(size: 22, weight: .bold, design: .rounded))
                            .foregroundColor(Color.brandNavy)
                    }
                    Spacer()
                    Image(systemName: "list.bullet.clipboard.fill")
                        .font(.system(size: 24))
                        .foregroundColor(Color.brandYellow)
                }
                .padding(.horizontal, 8)
                .padding(.top, 4)
                
                // Task List
                VStack(spacing: 10) {
                    ForEach($viewModel.tasks) { $task in
                        EnhancedTaskRow(task: $task, viewModel: viewModel)
                    }
                }
                .padding(.horizontal, 8)
                
                // Spacer for bottom padding
                Color.clear.frame(height: 20)
            }
        }
        .background(Color.watchBackground)
    }
}

// MARK: - TAB 3: HEALTH STATS
struct HealthTabView: View {
    @ObservedObject var viewModel: ReceiverVM
    let stepProgressPercentage: Int
    let stepGoal: Int
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 14) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("HEALTH")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(Color.brandLightBlue)
                            .tracking(1.2)
                        Text("Statistics")
                            .font(.system(size: 22, weight: .bold, design: .rounded))
                            .foregroundColor(Color.brandNavy)
                    }
                    Spacer()
                    Image(systemName: "heart.text.square.fill")
                        .font(.system(size: 24))
                        .foregroundColor(Color.brandLightBlue)
                }
                .padding(.horizontal, 8)
                .padding(.top, 4)
                
                // Steps Detail Card
                VStack(spacing: 14) {
                    HStack {
                        Image(systemName: "figure.walk.circle.fill")
                            .font(.system(size: 32))
                            .foregroundColor(Color.brandLightBlue)
                        
                        Spacer()
                        
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("\(viewModel.steps)")
                                .font(.system(size: 28, weight: .bold, design: .rounded))
                                .foregroundColor(Color.brandNavy)
                            Text("steps")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(.gray)
                        }
                    }
                    
                    // Progress Bar with Gradient
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule()
                                .fill(Color.gray.opacity(0.15))
                                .frame(height: 8)
                            
                            Capsule()
                                .fill(
                                    LinearGradient(
                                        colors: [Color.brandLightBlue, Color.brandSky],
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                                .frame(
                                    width: geo.size.width * CGFloat(stepProgressPercentage) / 100.0,
                                    height: 8
                                )
                                .shadow(color: Color.brandLightBlue.opacity(0.4), radius: 3, x: 0, y: 2)
                        }
                    }
                    .frame(height: 8)
                    
                    HStack {
                        Text("Goal: \(stepGoal)")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        Spacer()
                        Text("\(stepProgressPercentage)%")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(Color.brandLightBlue)
                    }
                }
                .padding(16)
                .background(Color.white)
                .cornerRadius(18)
                .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 3)
                .padding(.horizontal, 8)
                
                // Additional Health Metrics
                VStack(spacing: 10) {
                    HealthMetricRow(
                        icon: "heart.fill",
                        title: "Heart Rate",
                        value: "72 bpm",
                        color: .red
                    )
                    
                    HealthMetricRow(
                        icon: "flame.fill",
                        title: "Calories",
                        value: "1,245 kcal",
                        color: .orange
                    )
                }
                .padding(.horizontal, 8)
                
                // Spacer for bottom padding
                Color.clear.frame(height: 20)
            }
        }
        .background(Color.watchBackground)
    }
}

// MARK: - SUBVIEWS
struct QuickStatBadge: View {
    let icon: String
    let value: String
    let label: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 5) {
            Image(systemName: icon)
                .font(.system(size: 18))
                .foregroundColor(color)
            
            Text(value)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundColor(Color.brandNavy)
            
            Text(label)
                .font(.system(size: 9, weight: .medium))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(color.opacity(0.1))
        .cornerRadius(12)
    }
}

struct QuickAccessCard: View {
    let icon: String
    let title: String
    let value: String
    let subtitle: String
    let color: Color
    let progress: CGFloat
    
    var body: some View {
        HStack(spacing: 10) {
            ZStack {
                Circle()
                    .fill(color.opacity(0.15))
                    .frame(width: 38, height: 38)
                
                Image(systemName: icon)
                    .font(.system(size: 18))
                    .foregroundColor(color)
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.gray)
                
                Text(value)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundColor(Color.brandNavy)
                
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(color)
            }
            
            Spacer()
        }
        .padding(14)
        .background(Color.white)
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
    }
}

struct NextTaskCard: View {
    let task: TaskItem
    
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text("NEXT TASK")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(Color.brandYellow)
                    .tracking(1)
                Spacer()
                Image(systemName: "clock.fill")
                    .font(.system(size: 11))
                    .foregroundColor(Color.brandYellow)
            }
            
            Text(task.title)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(Color.brandNavy)
                .lineLimit(2)
            
            HStack(spacing: 4) {
                Image(systemName: "alarm")
                    .font(.system(size: 11))
                    .foregroundColor(.gray)
                Text(task.time)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.gray)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(
                colors: [Color.brandYellow.opacity(0.15), Color.brandYellow.opacity(0.05)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .cornerRadius(14)
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.brandYellow.opacity(0.3), lineWidth: 1)
        )
    }
}

struct EnhancedTaskRow: View {
    @Binding var task: TaskItem
    @ObservedObject var viewModel: ReceiverVM
    
    var body: some View {
        Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                viewModel.toggleTaskCompletion(for: task.id)
            }
        }) {
            HStack(spacing: 12) {
                // Animated Checkbox
                ZStack {
                    Circle()
                        .fill(task.isCompleted ? Color.brandGreen : Color.white)
                        .frame(width: 28, height: 28)
                        .overlay(
                            Circle()
                                .stroke(task.isCompleted ? Color.brandGreen : Color.gray.opacity(0.3), lineWidth: 2)
                        )
                    
                    if task.isCompleted {
                        Image(systemName: "checkmark")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.white)
                    }
                }
                
                // Task Info
                VStack(alignment: .leading, spacing: 3) {
                    Text(task.title)
                        .font(.system(size: 14, weight: .semibold))
                        .strikethrough(task.isCompleted, color: .gray)
                        .foregroundColor(task.isCompleted ? .gray : Color.brandNavy)
                        .lineLimit(2)
                    
                    HStack(spacing: 4) {
                        Image(systemName: "clock")
                            .font(.system(size: 10))
                        Text(task.time)
                            .font(.system(size: 11, weight: .medium))
                    }
                    .foregroundColor(task.isCompleted ? .gray.opacity(0.7) : Color.brandLightBlue)
                }
                
                Spacer()
            }
            .padding(14)
            .background(task.isCompleted ? Color.gray.opacity(0.05) : Color.white)
            .cornerRadius(14)
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(task.isCompleted ? Color.clear : Color.gray.opacity(0.1), lineWidth: 1)
            )
            .shadow(color: task.isCompleted ? .clear : .black.opacity(0.04), radius: 5, x: 0, y: 2)
        }
        .buttonStyle(.plain)
    }
}

struct HealthMetricRow: View {
    let icon: String
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(color.opacity(0.15))
                    .frame(width: 36, height: 36)
                
                Image(systemName: icon)
                    .font(.system(size: 16))
                    .foregroundColor(color)
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.gray)
                
                Text(value)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundColor(Color.brandNavy)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(.gray.opacity(0.3))
        }
        .padding(14)
        .background(Color.white)
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
    }
}

// MARK: - PREVIEW
#Preview {
    let previewVM = ReceiverVM()
    return WatchDashboardView(viewModel: previewVM)
}
