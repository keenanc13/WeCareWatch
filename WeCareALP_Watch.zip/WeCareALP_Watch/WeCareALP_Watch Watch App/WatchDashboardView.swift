import SwiftUI

struct WatchDashboardView: View {
    @ObservedObject var viewModel: ReceiverVM
    private let stepGoal = 6000
    
    private var stepProgressPercentage: Int {
        min(Int(Double(viewModel.steps) / Double(stepGoal) * 100), 100)
    }
    
    private var taskCompletionPercentage: Int {
        guard !viewModel.tasks.isEmpty else { return 0 }
        let completed = viewModel.tasks.filter { $0.isCompleted }.count
        return Int(Double(completed) / Double(viewModel.tasks.count) * 100)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Good Morning,")
                            .font(.system(size: 10))
                            .foregroundColor(.gray)
                        Text("Grandpa")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundColor(Color.brandSky)
                    }
                    Spacer()
                    Image(systemName: "person.circle.fill")
                        .font(.title2)
                        .foregroundColor(Color.brandSky)
                }
                .padding(.top, 4)
                
                // Summary Card
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .stroke(Color.brandGreen.opacity(0.3), lineWidth: 6)
                        Circle()
                            .trim(from: 0, to: CGFloat(taskCompletionPercentage) / 100.0)
                            .stroke(Color.brandGreen, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                            .rotationEffect(.degrees(-90))
                        
                        VStack(spacing: 0) {
                            Text("\(taskCompletionPercentage)%")
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundColor(Color.brandGreen)
                            Text("Tasks")
                                .font(.system(size: 8))
                                .foregroundColor(.gray)
                        }
                    }
                    .frame(width: 55, height: 55)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Image(systemName: "figure.walk")
                                .font(.system(size: 12))
                                .foregroundColor(Color.brandSky)
                            Text("Steps")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.white)
                        }
                        Text("\(viewModel.steps) / \(stepGoal)")
                            .font(.system(size: 10))
                            .foregroundColor(.gray)
                        
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(Color.gray.opacity(0.3)).frame(height: 4)
                                Capsule().fill(Color.brandSky)
                                    .frame(width: geo.size.width * CGFloat(stepProgressPercentage) / 100.0, height: 4)
                            }
                        }
                        .frame(height: 4)
                    }
                }
                .padding(10)
                .background(Color.white.opacity(0.1))
                .cornerRadius(12)
                
                Divider().background(Color.gray.opacity(0.4)).padding(.vertical, 4)

                // Task List
                VStack(alignment: .leading, spacing: 8) {
                    Text("DAILY TASKS")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(Color.brandYellow)
                        .tracking(1)
                    
                    ForEach($viewModel.tasks) { $task in
                        WatchTaskRow(task: $task, viewModel: viewModel)
                    }
                }
            }
            .padding(.horizontal)
        }
    }
}

struct WatchTaskRow: View {
    @Binding var task: TaskItem
    @ObservedObject var viewModel: ReceiverVM
    
    var body: some View {
        Button(action: {
            withAnimation { viewModel.toggleTaskCompletion(for: task.id) }
        }) {
            HStack(spacing: 10) {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundColor(task.isCompleted ? Color.brandGreen : Color.gray)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(task.title)
                        .font(.system(size: 14, weight: .medium))
                        .strikethrough(task.isCompleted, color: .gray)
                        .foregroundColor(task.isCompleted ? .gray : .white)
                    Text(task.time)
                        .font(.system(size: 11))
                        .foregroundColor(task.isCompleted ? .gray.opacity(0.6) : Color.brandSky)
                }
                Spacer()
            }
            .padding(10)
            .background(Color.white.opacity(0.12))
            .cornerRadius(10)
        }
        .buttonStyle(.plain)
    }
}
